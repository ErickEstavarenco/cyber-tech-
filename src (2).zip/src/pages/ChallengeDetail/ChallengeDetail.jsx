// src/pages/ChallengeDetail/ChallengeDetail.jsx
import React from "react";

export default function ChallengeDetail() {
  return (
    <div className="p-6 text-center text-slate-600 min-h-screen bg-gradient-to-b from-[#002D72] to-[#007BFF] text-white">
      <h2 className="text-2xl font-bold mb-3">Challenge Detail</h2>
      <p className="text-lg opacity-90">Página de detalhes do desafio em desenvolvimento...</p>
    </div>
  );
}
