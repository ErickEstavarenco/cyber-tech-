import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css'; // Usando CSS Modules
import challenges from '../../data/challenges.json';

// Importações de Imagens
import iconAlgoritmo from '../../assets/icons/icon-algoritmo.png'; 
import iconPerson from '../../assets/icons/icon-person.png';     
import iconFood from '../../assets/icons/icon-food.png';       
import iconSunMoon from '../../assets/icons/icon-sun-moon.png';  

const AlgorithmIcon = () => (
  <img src={iconAlgoritmo} alt="Ícone de algoritmo" className={styles.infoCardIcon} />
);

const ChallengeCardIcon = ({ iconSrc, altText }) => (
  <img src={iconSrc} alt={altText} className={styles.challengeCardIcon} />
);

function Home() {
  const iconMap = {
    person: iconPerson,
    food: iconFood,
    'sun-moon': iconSunMoon,
    algoritmo: iconAlgoritmo,
  };

  // Pega os 3 primeiros desafios para a home
  const featuredChallenges = challenges.slice(0, 3); 

  return (
    <div className={styles.home}>
      
      {/* Seção Hero */}
      <section className={styles.heroSection}>
        <div className="container">
          <p className={styles.welcomeText}>BEM VINDO!</p>
          <h1 className={styles.mainTitle}>Aprenda programação</h1>
          <h2 className={styles.subtitle}>Conceitos básicos de lógica de programação para iniciantes</h2>
        </div>
      </section>

      <div className="container">
        {/* Seção Algoritmo - Card Limpo */}
        <section className={styles.algorithmSection}>
          <div className={styles.infoCard}>
            <AlgorithmIcon />
            <div className={styles.infoText}>
              <h3>O que é um algoritmo?</h3>
              <p>Um algoritmo é uma maneira de resolver problemas ou realizar tarefas de forma sequencial.</p>
              {/* Este botão usa o estilo global .btn-primary */}
              <Link to="/blog" className="btn-primary">Ler mais</Link>
            </div>
          </div>
        </section>

        {/* Seção Desafios Práticos */}
        <section className={styles.challengesSection}>
          <h2>Desafios práticos</h2>
          <p>Experimente o funcionamento de if/else por meio de exercícios</p>
          
          <div className={styles.challengeCardsList}>
            {featuredChallenges.map(challenge => (
              <Link key={challenge.id} to={`/desafios/${challenge.slug}`} className={styles.challengeCard}>
                <ChallengeCardIcon iconSrc={iconMap[challenge.icon]} altText={challenge.title} />
                <p>{challenge.title}</p>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

export default Home;