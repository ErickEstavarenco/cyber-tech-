import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx"; 

// A linha "import './index.css';" NÃO DEVE estar aqui.
// Esta linha (abaixo) DEVE estar aqui.
import "./styles/globals.css"; 

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);