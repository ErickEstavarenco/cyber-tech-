import React from "react";
import { Link } from "react-router-dom";
import { Code2, User, Utensils, SunMoon } from "lucide-react"; // ÍCONES VETORIAIS
import challenges from "../data/challenges.json";

export default function Home() {
  // Mapa de ícones vetoriais
  const iconMap = {
    person: <User size={48} className="text-blue-600 mb-3" />,
    food: <Utensils size={48} className="text-blue-600 mb-3" />,
    "sun-moon": <SunMoon size={48} className="text-blue-600 mb-3" />,
    algoritmo: <Code2 size={48} className="text-blue-600 mb-3" />,
  };

  const featuredChallenges = challenges.slice(0, 3);

  return (
    <div className="flex flex-col items-center">
      {/* 🔷 SEÇÃO HERO */}
      <section className="w-full bg-gradient-to-b from-blue-900 to-blue-700 text-center py-16 px-4">
        <p className="text-blue-200 uppercase tracking-widest font-semibold text-sm mb-2">
          Bem-vindo!
        </p>
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-3">
          Aprenda programação
        </h1>
        <h2 className="text-blue-200 text-lg max-w-xl mx-auto leading-relaxed">
          Conceitos básicos de lógica de programação para iniciantes
        </h2>
      </section>

      {/* 🔶 SEÇÃO - O QUE É UM ALGORITMO */}
      <section className="max-w-3xl w-full my-10 px-4">
        <div className="bg-yellow-50 border border-yellow-400 rounded-lg shadow-md p-6 flex flex-col md:flex-row items-center gap-4">
          <Code2 size={64} className="text-blue-600" />
          <div className="text-center md:text-left">
            <h3 className="text-xl font-bold text-gray-800 mb-2">
              O que é um algoritmo?
            </h3>
            <p className="text-gray-600 mb-3">
              Um algoritmo é uma sequência de passos usados para resolver um
              problema ou executar uma tarefa de forma lógica.
            </p>
            <Link
              to="/blog"
              className="bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-semibold hover:bg-blue-700 transition"
            >
              Ler mais
            </Link>
          </div>
        </div>
      </section>

      {/* 🧩 SEÇÃO - DESAFIOS PRÁTICOS */}
      <section className="w-full max-w-5xl mb-16 px-4 text-center">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">
          Desafios práticos
        </h2>
        <p className="text-gray-500 mb-8">
          Experimente o funcionamento de estruturas condicionais e lógica
          básica com desafios interativos
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 justify-items-center">
          {featuredChallenges.map((challenge) => (
            <Link
              key={challenge.id}
              to={`/desafios/${challenge.slug}`}
              className="w-56 bg-yellow-50 border border-yellow-400 rounded-lg p-5 flex flex-col items-center justify-center hover:shadow-lg hover:-translate-y-1 transition-all"
            >
              {iconMap[challenge.icon]}
              <p className="font-semibold text-gray-800 text-sm">
                {challenge.title}
              </p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
