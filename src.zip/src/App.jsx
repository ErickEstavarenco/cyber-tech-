// src/App.jsx

import React from 'react';
import { Routes, Route } from 'react-router-dom';
import './styles/globals.css';

// CORREÇÃO: Caminho do Header (já estava correto, mas mantido)
import Header from './components/Header.jsx'; 

// CORREÇÃO: Todos os caminhos de página agora incluem o nome do arquivo e a extensão .jsx
import Home from './pages/Home/Home.jsx';
import Login from './pages/Login/Login.jsx';
import Cadastro from './pages/Cadastro/Cadastro.jsx';
import Blog from './pages/Blog/Blog.jsx';
import ChallengeList from './pages/ChallengeList/ChallengeList.jsx';
import ChallengeDetail from './pages/ChallengeDetail/ChallengeDetail.jsx';


function App() {
  return (
    <div className="app-layout">
      <Header />

      <main>
        <Routes>
          {/* Rotas principais */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/cadastro" element={<Cadastro />} />

          {/* Rotas de navegação */}
          <Route path="/blog" element={<Blog />} />
          <Route path="/desafios" element={<ChallengeList />} />
          <Route path="/desafios/:slug" element={<ChallengeDetail />} />
        </Routes>
      </main>

      {/* <Footer /> */}
    </div>
  );
}

export default App;