// src/pages/ChallengeList.jsx
export default function ChallengeList() {
  return (
    <div style={{ padding: "2rem" }}>
      <h2>Lista de Desafios</h2>
      <p>Em breve aqui estarão os desafios interativos!</p>
    </div>
  );
}
