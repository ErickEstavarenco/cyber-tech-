import { useEffect, useState } from "react";
import challengesData from "../../data/challenges.json";
import "./Home.css";

export default function Home() {
  const [challenges, setChallenges] = useState([]);

  useEffect(() => {
    setChallenges(challengesData);
  }, []);

  return (
    <div className="home font-sans">
      {/* Hero Section */}
      <section className="hero text-center py-32 bg-gradient-to-b from-blue-900 to-blue-600 text-white">
        <h1 className="text-4xl font-bold mb-4">BEM-VINDO!</h1>
        <p className="text-lg mb-2">Aprenda programação</p>
        <p className="text-sm text-blue-100">
          Conceitos básicos de lógica de programação para iniciantes
        </p>
      </section>

      {/* Desafios */}
      <section id="desafios" className="p-10 text-center bg-white">
        <h2 className="text-3xl font-bold mb-8 text-blue-700">Desafios</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 justify-items-center">
          {challenges.map((challenge) => (
            <div
              key={challenge.id}
              className="bg-gradient-to-b from-blue-50 to-blue-100 rounded-2xl shadow-lg p-6 w-72 hover:scale-105 hover:shadow-xl transition"
            >
              <img
                src={`/assets/icons/icon-${challenge.icon}.png`}
                alt={challenge.title}
                className="w-16 h-16 mx-auto mb-4"
              />
              <h3 className="font-semibold text-xl text-blue-800 mb-2">
                {challenge.title}
              </h3>
              <p className="text-sm text-gray-600">{challenge.concept}</p>
            </div>
          ))}
        </div>
      </section>

      {/* O que é um Algoritmo */}
      <section className="bg-blue-50 py-20 text-center">
        <h2 className="text-3xl font-bold text-blue-700 mb-6">
          O que é um Algoritmo?
        </h2>
        <div className="max-w-2xl mx-auto text-gray-700 text-lg">
          <p className="mb-4">
            Um algoritmo é uma sequência de passos lógicos e finitos que
            resolvem um problema. É como uma receita que ensina o computador o
            que fazer, passo a passo.
          </p>
          <p>
            No mundo da programação, aprender a pensar de forma algorítmica é
            essencial para criar soluções eficientes e organizadas.
          </p>
        </div>
      </section>
    </div>
  );
}
